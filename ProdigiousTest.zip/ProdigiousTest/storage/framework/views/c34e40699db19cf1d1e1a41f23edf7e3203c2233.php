<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>CRUDE test</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css"> 

        <!-- Styles -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

        <!-- JavaScript -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top">       

            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav" id="link-white">
                    <li>
                        <a href="<?php echo e(route('user.index')); ?>" style="text-decoration: none">
                            <span class="glyphicon glyphicon-home"></span> 
                            <span id="underline">Home</span>
                        </a>
                    </li>
            </div>       
        </nav> 
        <?php if(session('message')): ?>
        <div class="alert alert-success alert-dismissible" style="padding-top:60px">
            <a href="" class="close" 
               data-dismiss="alert"
               aria-label="close">&times;</a>
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('warning')): ?>
        <div class="alert alert-warning alert-dismissible" style="padding-top:60px">
            <a href="" class="close" 
               data-dismiss="alert"
               aria-label="close">&times;</a>
            <?php echo e(session('warning')); ?>

        </div>
        <?php endif; ?>
        <div id="line-one">   
            <div class="container">
                <div class="row">
                    <div class="col-md-12" style="padding-top:30px" id="center"> 
                        <h1><b>Usuários</b></h1>
                        <br>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <br>
            
                        <form action="/search" method="get">
                            <div class="input_group pull-left">
                                <input type="search" name="search" class="form-control input-sm pull-left">
                            </div>
                            <button type="submit" class="btn btn-default btn-sm pull-left">Pesquisar</button>
                        </form>

                        <a href="<?php echo e(route('user.create')); ?>" 
                           class="btn btn-default btn-sm pull-left">
                            <span class="glyphicon glyphicon-plus"></span> Adicionar</a>
                    </div>           
                </div>
                <div class="row">
                    <div class="col-md-12">   
                        <br />
                        <h4 id="center"><b>USUÁRIOS CADASTRADOS (<?php echo e($total); ?>)</b></h4>
                        <br>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th id="center">Id</th>
                                        <th>Nome</th>
                                        <th>CPF</th>
                                        <th id="center">email</th>
                                        <th>Descrição</th>                
                                        <th id="center">Imagem</th> 
                                        <th>Editar</th>        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td id="center"><?php echo e($user->id); ?></td>
                                        <td title="Nome"><?php echo e($user->name); ?></td>
                                        <td title="CPF"><?php echo e($user->cpf); ?></td>
                                        <td title="email" id="center"><?php echo e($user->email); ?></td>
                                        <td title="description" id="center"><?php echo e($user->description); ?></td>
                                        <td id="center">
                                        <?php if($user->image != null): ?>
                                        <img src="<?php echo e(URL::asset('storage/'. $user->image)); ?>" width="25" height="25" alt=""/>  
                                        <?php endif; ?>
                                        </td>
                                        <td id="center">
                                            <a href="<?php echo e(route('user.edit', $user->id)); ?>" 
                                               data-toggle="tooltip" 
                                               data-placement="top"
                                               title="Alterar"><i class="fa fa-pencil"></i></a>
                                            &nbsp;<form style="display: inline-block;" method="POST" 
                                                        action="<?php echo e(route('user.destroy', $user->id)); ?>"                                                        
                                                        data-toggle="tooltip" data-placement="top"
                                                        title="Excluir" 
                                                        onsubmit="return confirm('Confirma exclusão?')">
                                                <?php echo e(method_field('DELETE')); ?><?php echo e(csrf_field()); ?>                                                
                                                <button type="submit" style="background-color: #fff">
                                                    <a><i class="fa fa-trash-o"></i></a>                                                    
                                                </button></form></td>               
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            </body>
            </html>

<?php /**PATH C:\Users\Mikael\Desktop\ProdigiousTest\resources\views/list-users.blade.php ENDPATH**/ ?>