<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\User;
use Carbon\Carbon;

class RegisterController extends Controller
{
    public function index(){
        $users = User::all();
        $total = User::all()->count();
        return view('list-users', compact('users', 'total'));
    }

    public function create(){
        return view('include-users');
    }

    public function store(Request $request){
        $consult1 = User::consultUser([
            'email'=>$request->email
        ]);
        if(!empty($consult1)){
            return redirect()->route('user.index')->with('warning', 'Email já cadastrado');
        }

        $consult2 = User::consultUser([
            'cpf'=>$request->cpf
        ]);
        if(!empty($consult2)){
            return redirect()->route('user.index')->with('warning', 'CPF já cadastrado');
        }

        $new_user = new User;
        $new_user->name = $request->name;
        $new_user->email = $request->email;
        $new_user->password = $request->password;
        $new_user->cpf = $request->cpf;
        $new_user->description = $request->description;

        if($request->has('image')){
            $new_user->image = $request->file('image')->store('img', 'public');
        }

        $new_user->save();
        return redirect()->route('user.index')->with('message', 'Usuário adicionado com sucesso!');
    }

    public function search(Request $request){        
        $search = $request->get('search');
        $users = User::where('name', 'LIKE', '%'.$search.'%')->get();
        $total = $users->count();
        return view('list-users', compact('users', 'total'));
    }

    public function edit($id){
        $user = User::findOrFail($id);
        return view('alter-user', compact('user'));
    }



    public function update(Request $request, $id){


        $consult1 = User::consultUser([
            'email'=>$request->email
        ]);

        if(!empty($consult1) and $consult1 != intval($id)){
            return redirect()->route('user.index')->with('warning', 'Email já cadastrado');
        }

        $consult2 = User::consultUser([
            'cpf'=>$request->cpf
        ]);

        if(!empty($consult2) and $consult2 != intval($id)){
            return redirect()->route('user.index')->with('warning', 'CPF já cadastrado');
        }

        $user = User::findOrFail($id);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->cpf = $request->cpf;
        $user->description = $request->description;

        if($request->has('image')){
            Storage::delete('public/'.$user->image);
            $user->image = $request->file('image')->store('img', 'public');
        }

        $user->save();
        return redirect()->route('user.index')->with('message', 'Usuário atualizado com sucesso!');
    }

    public function destroy($id){
        $user = User::FindOrFail($id);
        if($id == null){
            return redirect()->route('user.index')->with('warning', 'Ocorreu um erro durante a exclusão');
        }


        if($user->image != null){
            Storage::delete('public/'.$user->image);
        }
        $user->delete();
        return redirect()->route('user.index')->with('message', 'Usuário excluído com sucesso!');
    }
}